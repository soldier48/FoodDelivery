package freaktemplate.Adapter;

import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Redixbit 2 on 12-10-2016.
 */

class ListViewHolder {
    public TextView txt_name;
    public TextView txt_desc;
    public  TextView txt_price;
    public Button btn_minus;
    public Button btn_plus;
    public EditText edTextQuantity;

}