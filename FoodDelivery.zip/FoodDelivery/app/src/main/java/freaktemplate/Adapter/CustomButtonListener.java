package freaktemplate.Adapter;

import android.widget.EditText;

/**
 * Created by Redixbit 2 on 12-10-2016.
 */
public interface CustomButtonListener {
    public void onButtonClickListener(int position, EditText editText, int value);
}
